package com.rp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
