package com.rp.dto;

import lombok.Data;

@Data
public class RestResponse {
	private String response;

}
