package com.rp.dto;

import lombok.Data;

@Data
public class Register {

    private String name;

    private String email;

    private String password;

    private String phoneNo;

}
